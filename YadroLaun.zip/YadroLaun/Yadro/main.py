import sys
from lexer import Lexer
from parser import Parser
from interpreter import Interpreter

def main():
    # Проверяем, передан ли аргумент командной строки
    if len(sys.argv) < 2:
        print("Использование: python main.py <имя_файла>")
        return

    # Получаем имя файла из аргументов командной строки
    filename = sys.argv[1]

    try:
        with open(filename, 'r', encoding='utf-8') as file:
            code = file.read()
    except FileNotFoundError:
        print(f"Ошибка: Файл '{filename}' не найден.")
        return
    except Exception as e:
        print(f"Ошибка при чтении файла: {e}")
        return

    # Лексический анализ
    lexer = Lexer(code)
    tokens = lexer.tokenize()

    # Синтаксический анализ
    parser = Parser(tokens)
    statements = parser.parse()

    # Интерпретация
    interpreter = Interpreter()
    interpreter.interpret(statements)

    # Вывод переменных
    print(interpreter.variables)

if __name__ == '__main__':
    main()