import re

class Lexer:
    def __init__(self, code):
        self.code = code
        self.position = 0
        self.current_char = self.code[self.position] if self.code else None
        self.tokens = []

    def error(self):
        raise Exception("Ошибка лексического анализа")

    def advance(self):
        self.position += 1
        if self.position < len(self.code):
            self.current_char = self.code[self.position]
        else:
            self.current_char = None

    def skip_whitespace(self):
        while self.current_char is not None and self.current_char.isspace():
            self.advance()

    def variable(self):
        result = ''
        while self.current_char is not None and re.match(r'[а-яА-Яa-zA-Z_]', self.current_char):
            result += self.current_char
            self.advance()
        return ('ИД', result)

    def string(self):
        result = ''
        self.advance()  # Пропускаем начальную кавычку
        while self.current_char is not None and self.current_char != '"':
            result += self.current_char
            self.advance()
        self.advance()  # Пропускаем конечную кавычку
        return ('СТРОКА', result)

    def tokenize(self):
        while self.current_char is not None:
            if self.current_char.isspace():
                self.skip_whitespace()
                continue
            if self.current_char == '"':
                self.tokens.append(self.string())
                continue
            if re.match(r'[а-яА-Яa-zA-Z_]', self.current_char):
                self.tokens.append(self.variable())
                continue
            if self.current_char == '=':
                self.tokens.append(('EQUAL', '='))
                self.advance()
                continue
            if self.current_char == ';':
                self.tokens.append(('SEMICOLON', ';'))
                self.advance()
                continue
            self.error()
        return self.tokens