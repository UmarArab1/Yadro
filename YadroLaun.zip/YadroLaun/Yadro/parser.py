class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.current_token = self.tokens[0] if self.tokens else None
        self.position = 0

    def error(self):
        raise Exception("Ошибка синтаксического анализа")

    def advance(self):
        self.position += 1
        if self.position < len(self.tokens):
            self.current_token = self.tokens[self.position]
        else:
            self.current_token = None

    def parse(self):
        statements = []
        while self.current_token is not None:
            if self.current_token[0] == 'ИД':
                var_name = self.current_token[1]
                self.advance()
                if self.current_token[0] == 'EQUAL':
                    self.advance()
                    if self.current_token[0] == 'СТРОКА string_value = self.current_token[1]
                    self.advance()
                    if self.current_token[0] == 'SEMICOLON':
                        statements.append(('ASSIGN', var_name, string_value))
                        self.advance()
                    else:
                        self.error()
                else:
                    self.error()
            else:
                self.error()
        return statements