class Interpreter:
    def __init__(self):
        self.variables = {}

    def visit(self, node):
        if node[0] == 'ASSIGN':
            var_name = node[1]
            value = node[2]
            self.variables[var_name] = value

    def interpret(self, statements):
        for statement in statements:
            self.visit(statement)

    def get_variable(self, name):
        return self.variables.get(name, None)